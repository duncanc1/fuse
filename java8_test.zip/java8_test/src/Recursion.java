/**
 * Created by duncanc1 on 01/12/2016.
 */
public class Recursion {

  public static void main(String[] args) {

    System.out.println(factorial(10));

  }

  public static long factorial(long n) throws IllegalArgumentException {
    if(n < 0) {
      throw new IllegalArgumentException("Illegal number");
    } else if(n == 0) {
      return 1; //BASE CASE - stops going forever
    } else {
      return n * factorial(n - 1);
    }
  }
}
