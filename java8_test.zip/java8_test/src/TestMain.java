import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * Created by duncanc1 on 08/09/2016.
 */
public class TestMain {


  public static void main(String[] args) {

    Artist memberArtist = new Artist();
    memberArtist.setName("MemberArtist");
    memberArtist.setOrigin("Manchester");

    Artist a1 = new Artist();
    a1.setName("The artist 1");
    a1.setOrigin("Liverpool");

    Artist a2 = new Artist();
    a2.setName("artist 2");
    a2.setOrigin("Liverpool");

    Artist a3 = new Artist();
    a3.setName("The artist 3");
    a3.setOrigin("Edinburgh");

    Artist a4 = new Artist();
    a4.setName("artist 4");
    a4.setOrigin("Liverpool");

    Artist a5 = new Artist();
    a5.setName("artist 5");
    a5.setOrigin("Edinburgh");

    Artist a6 = new Artist();
    a6.setName("artist 6");
    a6.setOrigin("Liverpool");

    Artist a7 = new Artist();
    a7.setName("artist 7");
    a7.setOrigin("Edinburgh");


    List<Artist> artists = new ArrayList<>();
    artists.add(a1);
    artists.add(a2);
    artists.add(a3);
    artists.add(a4);
    artists.add(a5);
    artists.add(a6);
    artists.add(a7);

    TestMain main = new TestMain();
    main.testInternalIteration(artists);

    main.testMapStreamFunction();
    main.testFlatMap();
    main.testMaxMin();

    main.testReducer();

    Album al1 = new Album();
    al1.setName("The album 1");
    al1.setMusicians(Arrays.asList(a1, a2, a3));

    Track track1 = new Track("track 1", 200);
    Track track2 = new Track("track 2", 200);
    List<Track> tracks = new ArrayList<>();
    tracks.add(track1);
    tracks.add(track2);
    al1.setTracks(tracks);

    Album al2 = new Album();
    al2.setName("The album 1");
    al2.setMusicians(Arrays.asList(a1, a2, a3));

    Track track3 = new Track("track 3", 40);
    Track track4 = new Track("track 4", 50);
    List<Track> tracks2 = new ArrayList<>();
    tracks2.add(track3);
    tracks2.add(track4);
    al2.setTracks(tracks2);

    main.testmultipleOperations(al1);
    main.testTrackStream(al1);
    main.findLongTracks(Arrays.asList(al1,al2));

  }

  /**
   * Tests lambda stream processing and highlights lazy/eager methods
   * lazy - doesnt force generate return, eager forces generates a return.
   *
   * @param artists
   */
  public void testInternalIteration(List<Artist> artists) {


    //eg of lazy - no print out
    artists.stream()
      .filter(artist -> {
        System.out.println(artist.getName());
        return artist.getOrigin() == "Liverpool";
      });

    long count = artists.stream()
      .filter(artist -> {
        System.out.println(artist.getName());
        return artist.getOrigin() == "Liverpool";
      })
      .count();

    System.out.println(count);

    List<Artist> collectedArtists = artists.stream()
      .filter(artist ->
        artist.getOrigin() == "Liverpool")
      .collect(Collectors.toList());

    System.out.println(collectedArtists.toString());


    /**
     * By waiting until we know more about what result and operations are needed,
     * we can perform the computations more efficiently. A good example is finding the first number that is > 10.
     * We don’t need to evaluate all the elements to figure this out—only enough to find our first match.
     * It also means that we can string together lots of different operations over our collection and iterate over
     * the collection only once.
     */


  }

  public void testMapStreamFunction() {
    List<String> collected = Stream.of("a", "b", "hello")
      .map(string -> string.toUpperCase())
      .collect(Collectors.toList());

    System.out.println(collected);
  }


  /**
   * You’ve already seen the map operation, which replaces a value in a Stream with a new value.
   * Sometimes you want a variant of map in which you produce a new Stream object as the replacement.
   * Frequently you don’t want to end up with a stream of streams, though, and this is where flatMap comes in handy.
   */
  public void testFlatMap() {

    List<Integer> together = Stream.of(Arrays.asList(1, 2), Arrays.asList(3, 4))
      .flatMap(numbers -> numbers.stream())
      .collect(Collectors.toList());

    System.out.println(together);

  }


  /**
   * In order to inform the Stream that we’re using the length of the track, we give it a Comparator. Conveniently,
   * Java 8 has added a static method called comparing that lets us build a comparator using keys.
   * Previously, we always encountered an ugly pattern in which we had to write code that got a field out of both the
   * objects being compared, then compare these field values. Now, to get the same element out of both elements being compared,
   * we just provide a getter function for the value. In this case we’ll use getLength.
   * It’s worth reflecting on the comparing method for a moment. This is actually a function that takes a function and
   * returns a function. Pretty meta, I know, but also incredibly useful. At any point in the past, this method could
   * have been added to the Java standard library, but the poor readability and verbosity issues surrounding anonymous inner classes would have made it impractical. Now, with lambda expressions, it’s convenient and concise.
   * It’s now possible for max to be called on an empty Stream so that it returns what’s known as an Optional value.
   * An Optional value is a bit like an alien: it represents a value that may exist, or may not. If our Stream is empty,
   * then it won’t exist; if it’s not empty, then it will. Let’s not worry about the details of Optional for the moment,
   * since we’ll be discussing it in detail in Optional. The only thing to remember is that we can pull out the value
   * by calling the get method.
   */
  public void testMaxMin() {

    List<Track> tracks = Arrays.asList(new Track("Bakai", 524),
      new Track("Violets for Your Furs", 378),
      new Track("Time Was", 451));

    Track shortestTrack = tracks.stream()
      .min(Comparator.comparing(track -> track.getLength()))
      .get();


    System.out.println(shortestTrack);

  }

  public void testReducer() {
    int count = Stream.of(1, 2, 3)
      .reduce(0, (acc, element) -> acc + element);
    System.out.println("reducer :" + count);
  }


  /**
   * There’s a nice getMusicians method on our Album class that returns a Stream.
   * We use filter to trim down the artists to include only bands.
   * We use map to turn the band into its nationality.
   * We use collect(toList()) to put together a list of these nationalities.
   *
   * @param album
   */
  public void testmultipleOperations(Album album) {

    Set<String> origins = album.getMusicians()
      .filter(artist -> artist.getName().startsWith("The"))
      .map(artist -> artist.getOrigin())
      .collect(Collectors.toSet());

    System.out.println(origins);
  }

  public void testTrackStream(Album al1) {
    al1.getTracks()
      .forEach(track ->
        System.out.println(track)
      );
  }

  public Set<String> findLongTracks(List<Album> albums) {

    //old code to refactor
    /*Set<String> trackNames = new HashSet<>();
    for (Album album : albums) {
      for (Track track : album.getTracks()) {
        if (track.getLength() > 60) {
          String name = track.getName();
          trackNames.add(name);
        }
      }
    }
    return trackNames;*/

    //step 1 - still ugly
    /*Set<String> trackNames = new HashSet<>();
    albums.stream()
      .forEach(album -> {
        album.getTracks()
          .forEach(track -> {
            if (track.getLength() > 60) {
              String name = track.getName();
              trackNames.add(name);
            }
          });
      });
    return trackNames;*/

    //step 2 - still ugly
   /* Set<String> trackNames = new HashSet<>();
    albums.stream()
      .forEach(album -> {
        album.getTracks()
          .filter(track -> track.getLength() > 60)
          .map(track -> track.getName())
          .forEach(name -> trackNames.add(name));
      });
    return trackNames;*/

    //step 3 - better but can still remove set
    /*Set<String> trackNames = new HashSet<>();

    albums.stream()
      .flatMap(album -> album.getTracks())
      .filter(track -> track.getLength() > 60)
      .map(track -> track.getName())
      .forEach(name -> trackNames.add(name));

    return trackNames;*/

    //final solution

    return albums.stream()
      .flatMap(album -> album.getTracks())
      .filter(track -> track.getLength() > 60)
      .map(track -> {
        System.out.println(track.getName());
      return track.getName();})
      .collect(Collectors.toSet());
  }


}
