package test;

import main.VowelRecognition;
import org.junit.Test;
import static org.junit.Assert.*;
public class VowelRecognitionTest {

  @Test
  public void testVowelRecognition() {
    String str = "baceb";

    System.out.println("Vowels: " + VowelRecognition.getVowelCount(str));

    //System.out.println(VowelRecognition.getPerms(str, 0));
    //assertEquals(-1, VowelRecognition.getPerms());
  }
}
