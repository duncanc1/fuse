package designpatterns.behavioural.observer;

import java.io.IOException;

/**
 * Created with IntelliJ IDEA.
 * User: CD99910
 * Date: 07/03/13
 * Time: 12:25
 * To change this template use File | Settings | File Templates.
 */
public class TestObserver {

    public static void main(String[]args)throws IOException {
        System.out.println("Enter Text >");

        //this is the event source - a runnable that reads from command line and publishes to all observers
        final EventSource source = new EventSource();

        // the observer - waits for updates
        final ResponseHandler responseHandler = new ResponseHandler();
        //make the subscription to the source
        source.addObserver(responseHandler);

        Thread thread = new Thread(source);
        thread.start();
    }
}
