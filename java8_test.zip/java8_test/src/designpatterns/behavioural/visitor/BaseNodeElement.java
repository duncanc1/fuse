package designpatterns.behavioural.visitor;

/**
 * Created with IntelliJ IDEA.
 * User: CD99910
 * Date: 07/03/13
 * Time: 11:35
 * To change this template use File | Settings | File Templates.
 */
public class BaseNodeElement implements IBaseNodeElement {
    IBaseNodeElement[] elements;
    private String name;
    private int ID = 0;

    public BaseNodeElement(String name){
        this.name = name;
        //all the child nodes to apply the appropriate visitor i.e actions to perform at thr node level
        this.elements = new IBaseNodeElement[]{new ChildNodeElement1("child element 1"),
                new ChildNodeElement2("child element 2"), new ChildNodeElement3("child node 3")};
    }

    public void setName(String name) {
        this.name = name;
        System.out.println("Base node name changed to " + name);
    }

    public void setID(int ID) {
        this.ID = ID;
        System.out.println("Base node id changed to " + ID);
    }

    /**
     * this will visit every node in the collection and the base node also
     *
     * @param nodeElementVisitor
     */
    @Override
    public void accept(NodeElementVisitor nodeElementVisitor) {
        for(IBaseNodeElement element : elements){
            element.accept(nodeElementVisitor);
        }
        nodeElementVisitor.visit(this);
    }
}
