package designpatterns.behavioural.visitor;

import java.io.IOException;

/**
 * Created with IntelliJ IDEA.
 * User: CD99910
 * Date: 07/03/13
 * Time: 12:06
 * To change this template use File | Settings | File Templates.
 */
public class VisitorTest {

    public static void main(String[] args)throws IOException{


        //aggregation - soft "has-a" association(empty diamond) i.e when conataining class destroyed - receiver not
        //composition - hard "owns-s" association(filled diamond) i.e strong life cycle association
        /*
        Allows different algos to be applied to all nodes without changing the structure of the elements

         */

        BaseNodeElement baseNodeElement = new BaseNodeElement("Base node");
        baseNodeElement.accept(new ChangeNameVisitor());
        baseNodeElement.accept(new IncrementIdVisitor());
    }
}
