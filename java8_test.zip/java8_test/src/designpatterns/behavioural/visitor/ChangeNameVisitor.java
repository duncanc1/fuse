package designpatterns.behavioural.visitor;

/**
 * Created with IntelliJ IDEA.
 * User: CD99910
 * Date: 07/03/13
 * Time: 11:52
 * To change this template use File | Settings | File Templates.
 */
public class ChangeNameVisitor implements NodeElementVisitor{

    @Override
    public void visit(BaseNodeElement baseNodeElement) {
        baseNodeElement.setName("base node");
    }

    @Override
    public void visit(ChildNodeElement1 childNodeElement1) {
        childNodeElement1.setName("child 1");
    }

    @Override
    public void visit(ChildNodeElement2 childNodeElement2) {
        childNodeElement2.setName("child 2");
    }

    @Override
    public void visit(ChildNodeElement3 childNodeElement3) {
        childNodeElement3.setName("child 3");
    }
}
