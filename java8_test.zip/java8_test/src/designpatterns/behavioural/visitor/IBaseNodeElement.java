package designpatterns.behavioural.visitor;

/**
 * Created with IntelliJ IDEA.
 * User: CD99910
 * Date: 07/03/13
 * Time: 11:20
 * To change this template use File | Settings | File Templates.
 */
public interface IBaseNodeElement {

    void accept(NodeElementVisitor nodeElementVisitor);
}
