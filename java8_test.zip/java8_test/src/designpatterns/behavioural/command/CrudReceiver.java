package designpatterns.behavioural.command;

/**
 * Created with IntelliJ IDEA.
 * User: CD99910
 * Date: 07/03/13
 * Time: 10:25
 * To change this template use File | Settings | File Templates.
 */
public class CrudReceiver {

    public void doDelete(){
        System.out.println("Performing delete");
    }

    public void doSave(){
        System.out.println("Performing save");
    }
}
