package designpatterns.behavioural.command;

/**
 * Created with IntelliJ IDEA.
 * User: CD99910
 * Date: 07/03/13
 * Time: 10:20
 * To change this template use File | Settings | File Templates.
 */

/*
The command interface

 */

public interface Command {
    void execute();
}
