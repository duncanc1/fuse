package designpatterns.behavioural.command;

/**
 * Created with IntelliJ IDEA.
 * User: CD99910
 * Date: 07/03/13
 * Time: 10:30
 * To change this template use File | Settings | File Templates.
 */
public class DeleteCommandImpl implements Command {

    //aggregation - soft "has-a" association(empty diamond) i.e when conataining class destroyed - receiver not
    //composition - hard "owns-s" association(filled diamond) i.e strong life cycle association
    private CrudReceiver receiver;

    public DeleteCommandImpl(CrudReceiver receiver) {
        this.receiver = receiver;
    }

    @Override
    public void execute() {
        this.receiver.doDelete();
    }
}
