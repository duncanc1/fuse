package designpatterns.behavioural.command;

import java.util.ArrayList;
import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: CD99910
 * Date: 07/03/13
 * Time: 10:22
 * To change this template use File | Settings | File Templates.
 *
 * THIS IS THE INVOKER
 *
 */
public class CrudInvoker {
    private List<Command> history = new ArrayList<Command>();

    public void storeAndExecute(Command cmd){
        this.history.add(cmd);
        cmd.execute();
    }
}
