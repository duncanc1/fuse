package designpatterns.behavioural.strategy;

import java.util.Objects;

/**
 * Created with IntelliJ IDEA.
 * User: CD99910
 * Date: 07/03/13
 * Time: 13:19
 * To change this template use File | Settings | File Templates.
 */
public class Context {

    //composition - filled diamond in UML
    private Strategy strategy;

    public Context(Strategy strategy) {
        this.strategy = strategy;
    }

    public int executeStrategy(int a, int b)

  @Override
  public boolean equals(Object o) {
    if (this == o) return true;
    if (o == null || getClass() != o.getClass()) return false;
    Context context = (Context) o;
    return Objects.equals(strategy, context.strategy);
  }

  @Override
  public int hashCode() {
    return Objects.hash(strategy);
  }
}
