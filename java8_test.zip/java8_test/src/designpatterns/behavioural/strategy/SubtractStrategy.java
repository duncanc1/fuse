package designpatterns.behavioural.strategy;

/**
 * Created with IntelliJ IDEA.
 * User: CD99910
 * Date: 07/03/13
 * Time: 13:17
 * To change this template use File | Settings | File Templates.
 */
public class SubtractStrategy implements Strategy {

    @Override
    public int executeAlgorithm(int a, int b) {
        System.out.println("subtracting");
        return a - b;
    }
}
