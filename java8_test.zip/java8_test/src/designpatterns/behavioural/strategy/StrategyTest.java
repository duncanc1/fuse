package designpatterns.behavioural.strategy;

import java.io.IOException;

/**
 * Created with IntelliJ IDEA.
 * User: CD99910
 * Date: 07/03/13
 * Time: 12:41
 * To change this template use File | Settings | File Templates.
 */
public class StrategyTest {

    //aggregation - soft "has-a" association(empty diamond) i.e when conataining class destroyed - receiver not
    //composition - hard "owns-s" association(filled diamond) i.e strong life cycle association

    public static void main(String[] args) throws IOException{

        Context context;
        context = new Context(new AddStrategy());
        int result1 = context.executeStrategy(2,1);

        context = new Context(new SubtractStrategy());
        int result2 = context.executeStrategy(2,1);

        System.out.println("Result 1:" + result1);
        System.out.println("Result 2:" + result2);
    }
}
