package main;

public class ReverseStringRecursive {
  public static void main(String[] args) {
    String str = "this is a string";
    System.out.println(reverseRecursively(str));
  }

  public static String reverseRecursively(String str) {

//base case to handle one char string and empty string

    if (str.length() < 2) {

      return str;

    }
    System.out.println(str);
    String retStr = reverseRecursively(str.substring(1));
    System.out.println(retStr);
    return retStr + str.charAt(0);

  }
}
