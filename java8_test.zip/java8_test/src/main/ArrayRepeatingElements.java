package main;

import java.util.HashSet;

public class ArrayRepeatingElements {

  private static void repeatingElemnts(int[] arr) {
    if(arr.length <=1)
      System.out.println("No repeating elements");

    HashSet<Integer> distinct = new HashSet();
    for (int i = 0; i < arr.length; i++) {

      Boolean success = distinct.add(arr[i]);
      if(!success) {
        System.out.printf("Duplicate element : %d", arr[i]);
      }
    }
  }

  public static void main(String[] args) {
    int[] arr = {1,1,3,5,1,4,2,6,8,9,0,5};
    repeatingElemnts(arr);
  }
}
