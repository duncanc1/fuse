package main;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

/**
 * Created by duncanc1 on 21/09/2016.
 */
public class Futures {
  String name;
  int value;

  public static void main(String[] args) {
    try {
      execB(execA()).get();
    } catch(InterruptedException|ExecutionException e) {}
  }
  Futures(String name, int value) {
    this.name = name;
    this.value = value;
  }

  void runMethod() {
    System.out.println("Entering " + name);
    try {
      Thread.sleep(value * 1000);
    } catch(InterruptedException e) {}
    System.out.println("Exiting " + name);
  }
  public static CompletableFuture<Void> execA() {
    return(
      CompletableFuture.<Void>allOf(
        CompletableFuture.runAsync(() -> (new Futures("a1", 4)).runMethod()),
        CompletableFuture.runAsync(() -> (new Futures("a2", 2)).runMethod()),
        CompletableFuture.runAsync(() -> (new Futures("a3", 1)).runMethod()))
    );
  }
  public static CompletableFuture<Void> execB(CompletableFuture<Void> prev) {
    try {
      prev.get();
    } catch (InterruptedException|ExecutionException e) {}
    return(
      CompletableFuture.<Void>allOf(
        CompletableFuture.runAsync(() -> (new Futures("b1", 2)).runMethod()),
        CompletableFuture.runAsync(() -> (new Futures("b2", 3)).runMethod()),
        CompletableFuture.runAsync(() -> (new Futures("b3", 1)).runMethod())));
  }
}
