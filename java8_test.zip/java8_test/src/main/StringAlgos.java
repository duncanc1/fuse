package main;

import java.util.*;

public class StringAlgos {
  public static void main(String[] args) {
    String str = "abadabbce";
    printAllRepeatingCharacters(str);
    printAllRepeatingCharactersRecursive(str, null);
    printFirstRepeatingCharacter(str);
    printNonFirstRepeatingCharacter(str);
    System.out.printf("Strings are anagrams : %b %n", stringsAreAnagrams("word", "wrdo"));
    System.out.printf("Strings are anagrams : %b %n", stringsAreAnagrams("word", "wrde"));
    reverseStringIterative(str);
    System.out.printf("Reverse string recursive : %s %n", reverseStringRecursive("abcde"));
    printPermetations("123");
  }

  static void printAllRepeatingCharacters(String str) {
    HashMap<Character, Integer> map = new HashMap<>();
    char[] charArray = str.toCharArray();
    for (Character c: charArray) {
      if(map.containsKey(c)) {
        map.put(c, map.get(c) + 1);
      } else {
        map.put(c, 1);
      }
    }

    map.forEach((key, value) -> {
      if(value > 1)
      System.out.printf("%s: %d %n", key, value);
    } );

  }

  static void printAllRepeatingCharactersRecursive(String str, HashMap<Character, Integer> accumulator) {
    //HashMap<Character, Integer> map = new HashMap<>();
    if(accumulator == null) {
      accumulator = new HashMap<>();
    }

    if (str.length() < 1) {
      accumulator.forEach((key, value) -> {
        if (value > 1)
          System.out.printf("%s: %d %n", key, value);
      });
    } else {
      Character c = str.charAt(str.length() - 1);
      if (accumulator.containsKey(c)) {
        accumulator.put(c, accumulator.get(c) + 1);
      } else {
        accumulator.put(c, 1);
      }
      printAllRepeatingCharactersRecursive(str.substring(0, str.length() - 1), accumulator);
    }



  }

  static void printFirstRepeatingCharacter(String str) {
    HashSet<Character> set = new HashSet<>();
    for (int i = 0; i < str.length(); i++) {
      char c = str.charAt(i);
      if(set.contains(c)) {
        System.out.printf("First repeating char: %s %n", c);
        break;
      } else {
        set.add(c);
      }
    }


  }

  static void printNonFirstRepeatingCharacter(String str) {
    Map<Character, Integer> map = new LinkedHashMap<>();
    for (int i = 0; i < str.length(); i++) {
      char c = str.charAt(i);
      if(map.containsKey(c)) {
        map.put(c, map.get(c) + 1);
      } else {
        map.put(c, 1);
      }
    }

    map.entrySet().stream().filter((entry) -> entry.getValue() == 1)
      .findFirst()
      .ifPresent((entry) -> System.out.printf("First non repeating char: %s %n" , entry.getKey()));

  }

  static Boolean stringsAreAnagrams(String str1, String str2) {
    if(str1.length() != str2.length())
      return false;

    char[] c1 = str1.toCharArray();
    char[] c2 = str2.toCharArray();
    Arrays.sort(c1);
    Arrays.sort(c2);

    return Arrays.equals(c1, c2);
  }

  static Boolean stringsAreAnagramsWithoutArrays(String str1, String str2) {
    return false;
  }

  static void reverseStringIterative(String str) {
    char[] arr = str.toCharArray();
    int start = 0;
    int end = arr.length -1;

    while(start < end) {
      char temp = arr[start];
      arr[start] = arr[end];
      arr[end] = temp;
      start++;
      end--;
    }

    System.out.println(String.valueOf(arr));
  }

  static String reverseStringRecursive(String str) {

    //WHITTLE DOWN TO 2 CHARS AND RETURN THEN THE OPERATION
    //CAN BE PERFORMED ON EACH STACKED RECURSIVE CALL
    if(str.length() < 2) {
      return str;
    }

    //should be written as return reverseStringRecursive(str.substring(1)) + str.charAt(0);
    //below is for understanding the flow
    String s = reverseStringRecursive(str.substring(1));
    return s  + str.charAt(0);
  }

  static void countCharacterInString(String str) {

  }

  static void countCharacterInStringRecursive(String str) {

  }

  static void convertIntegerStringToInt(String str) {

  }

  static void replaceCharWithOther(String str, String replace, String replacement) {

  }

  static void reverseStringOfWords(String str) {

  }

  static void removeDuplicateChars(String str) {

  }

  static void checkStringValidShuffle(String s1, String s2, String s3) {

  }

  static void findLongestPalindromeInString(String str) {

  }

  static void printPermetations(String str) {
    permutationFinder(str).forEach(System.out::println);
  }

 /* To get all the permutations, we will first take out the first char from String and permute the remaining chars.
  If String = “ABC”
  First char = A and remaining chars permutations are BC and CB.
  Now we can insert first char in the available positions in the permutations.
  BC -> ABC, BAC, BCA
  CB -> ACB, CAB, CBA*/

  public static Set<String> permutationFinder(String str) {
    Set<String> perm = new HashSet<String>();
    //Handling error scenarios
    if (str == null) {
      return null;
    } else if (str.length() == 0) {
      perm.add("");
      return perm;
    }
    char initial = str.charAt(0); // first character
    String rem = str.substring(1); // Full string without first character
    Set<String> words = permutationFinder(rem);
    for (String strNew : words) {
      for (int i = 0;i<=strNew.length();i++){
        perm.add(charInsert(strNew, initial, i));
      }
    }
    return perm;
  }

  public static String charInsert(String str, char c, int j) {
    String begin = str.substring(0, j);
    String end = str.substring(j);
    return begin + c + end;
  }



}
