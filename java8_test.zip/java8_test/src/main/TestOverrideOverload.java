package main;

import java.util.List;

/**
 * Created by duncanc1 on 05/11/2016.
 */
public class TestOverrideOverload {

  public class Animal {
    public void eat(){
      System.out.println("Animal Eating");
    }

    public void eat(String food){
      System.out.println(food);
    }
  }


  public class Horse extends Animal {
    @Override
    public void eat() {
      System.out.println("Horse eating");
    }

    public void eat(String food, String another){
      System.out.println("Horse:" + food);
    }

  }

  public class Cat extends Animal {

  }

  public static void main(String[] args) {
   /* Animal a = new main.TestOverrideOverload().new Animal();
    Animal h = new main.TestOverrideOverload().new Horse();
    a.eat();
    h.eat();
    a.eat("hay");
    //not allowed as reference type is Animal and it doesnt have this method. - h.eat("more hay", "another");
    String s1= new String("test");
    String s2 = new String("test");
    System.out.println(s1 == s2);

    int i1 = -123;
    int i2 = 12345;

    System.out.printf(">%1$(10d< \n", i1);

    //generic method test
    List<Animal> animals = new ArrayList<>();
    animals.add(new main.TestOverrideOverload().new Cat());
    animals.add(new main.TestOverrideOverload().new Horse());
    new main.TestOverrideOverload().addAnimal(animals);

    List<? extends Animal> li = new ArrayList<Cat>();

    double res = 9d / 8d + 4d * 2d / 3d ;

    //System.out.printf("%.2f \n",res);
    NumberFormat nf = new DecimalFormat("##.##");

    double res2 = 7d / 9d + 2d;
    System.out.println(nf.format(res2));
    //System.out.printf("%.2f \n",res2);

    double res3 = 9d - 3d * 7d;
    System.out.println(nf.format(res3));*/

    int [] nums = new int[10];
    nums[0] = 0;
    nums[1] = 1;
    nums[2] = 2;
    nums[3] = 3;
    nums[4] = 4;
    nums[5] = 5;

    int numEntries = nums.length;

  }

  public static void addAnimal(List<? super Cat> animals) {
    animals.add(new TestOverrideOverload().new Cat());
  }

}
