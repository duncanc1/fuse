package main;/*
 * Copyright 2014, Michael T. Goodrich, Roberto Tamassia, Michael H. Goldwasser
 *
 * Developed for use with the book:
 *
 *    Data Structures and Algorithms in Java, Sixth Edition
 *    Michael T. Goodrich, Roberto Tamassia, and Michael H. Goldwasser
 *    John Wiley & Sons, 2014
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

import java.time.Duration;
import java.time.Instant;
import java.util.Arrays;

/**
 * Demonstration of two recursive approaches to computing main.Fibonacci numbers.
 *
 * @author Michael T. Goodrich
 * @author Roberto Tamassia
 * @author Michael H. Goldwasser
 */
public class Fibonacci {

  public static long iterativeFibonacci(int n) {

    long f[] = new long[n+2]; // 1 extra to handle case, n = 0
    int i;

    /* 0th and 1st number of the series are 0 and 1*/
    f[0] = 0;
    f[1] = 1;

    for (i = 2; i <= n; i++)
    {
       /* Add the previous 2 numbers in the series
         and store it */
      f[i] = f[i-1] + f[i-2];
    }

    return f[n];
  }

  /** Returns the nth main.Fibonacci number (inefficiently). */
  public static long fibonacciBad(int n) {
    if (n <= 1)
      return n;
    else
      return fibonacciBad(n-2) + fibonacciBad(n-1);
  }

  /** Returns array containing the pair of main.Fibonacci numbers, F(n) and F(n-1). */
  public static long[] fibonacciGood(int n) {
    if (n <= 1) {
      long[] answer = {n, 0};
      return answer;
    } else {
      long[] temp = fibonacciGood(n - 1);            // returns $\{ F_{n-1},\, F_{n-2} \}$

      long[] answer = {temp[0] + temp[1], temp[0]};  // we want $\{ F_{n},\, F_{n-1} \}$
      return answer;
    }
  }
  /*
  Example fibonacci(10)
  -long[temp] = fibonacciGood(n-1)
  n=10 - 9,8,7,6,5,4,3,2,1 - n<=1 - returns {1,0}
  n=2 - returns {1,1} - {temp[0] + temp[1], temp[0]}
  n=3 - returns 1+1, 1 - {2,1}
  n=4 - returns 2+1, 2 - {3, 2}
  n=5 - returns 3+2, 3 - [5, 3]
  n=6 - returns 5+3, 5 - {8, 5}
  n=7 - returns 8+5, 8 - {13, 8}
  n=8 - returns 13+8, 13 - {21, 13}
  n=9 - returns 21+13, 21 - {34, 21}
  n=10 - returns 34+21, 34 - {55, 34}
  fibonacciGood(10)[0] = 55
   */

  /** Don't call this (infinite) version. */
  public static int fibonacci(int n) {
    return fibonacci(n);      // After all $F_n$ does equal $F_n$
  }

  public static void main(String[] args) {
    final int limit = 50;

    Instant start = Instant.now();
// CODE HERE

    System.out.println("The good...");
    for (int n = 0; n < limit; n++)
      System.out.println(n + ": " + fibonacciGood(n)[0]);

    Instant finish = Instant.now();
    long timeElapsed = Duration.between(start, finish).toMillis();
    System.out.println(timeElapsed);

    System.out.println("Single : " + fibonacciGood(5)[0]);
    Instant startIterative = Instant.now();
    for (int n = 0; n < limit; n++)
      System.out.println(n + ": " + iterativeFibonacci(n));

    Instant finishIterative = Instant.now();
    long timeElapsedIterative = Duration.between(startIterative, finishIterative).toMillis();
    System.out.println(timeElapsedIterative);
    System.out.println("Iterative: " + iterativeFibonacci(5));
    /*System.out.println("The bad...");
    for (int n = 0; n < limit; n++)
      System.out.println(n + ": " + fibonacciBad(n));*/


  }

}
