package main;

public class ArraySort {
  public static void main(String[] args) {

  }
}
