package main.lambda;

/**
 * Created by duncanc1 on 26/10/2016.
 */
public class Hello {

  public Runnable r = () -> {
    System.out.println(this);
    System.out.println(toString());

  };

  public String toString() {
    return "Hello's custom toString()";
  }

  public static void main(String[] args) {
    Hello h = new Hello();
    h.r.run();

    String message = "Howdy world";
    Runnable r1 = () -> System.out.println(message);
    r1.run();

    StringBuilder builder = new StringBuilder();
    Runnable r2 = () -> System.out.println(builder);
    builder.append("new");
    builder.append("test");
    r2.run();


  }

}
