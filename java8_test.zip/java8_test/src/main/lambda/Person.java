package main.lambda;

import java.util.Arrays;
import java.util.Comparator;

/**
 * Created by duncanc1 on 27/10/2016.
 */
public class Person {

  private String firstName;
  private String lastName;
  private int age;

  public Person(String firstName, String lastName, int age) {
    this.firstName = firstName;
    this.lastName = lastName;
    this.age = age;
  }

  public String getFirstName() {
    return firstName;
  }

  public void setFirstName(String firstName) {
    this.firstName = firstName;
  }

  public String getLastName() {
    return lastName;
  }

  public void setLastName(String lastName) {
    this.lastName = lastName;
  }

  public int getAge() {
    return age;
  }

  public void setAge(int age) {
    this.age = age;
  }

  @Override
  public String toString() {
    return "Person{" +
      "firstName='" + firstName + '\'' +
      ", lastName='" + lastName + '\'' +
      ", age=" + age +
      '}';
  }

  public static void main(String[] args) {
    Person[] people = new Person[] {
      new Person("Ted", "Neward", 41),
      new Person("A", "Bf", 41),
      new Person("B", "FG", 41),
      new Person("C", "RR", 41),
      new Person("D", "TR", 41),
    };

    Arrays.sort(people, Comparator.comparing(Person::getFirstName));





  }

}
