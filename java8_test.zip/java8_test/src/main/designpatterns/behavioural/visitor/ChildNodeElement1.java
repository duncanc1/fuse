package main.designpatterns.behavioural.visitor;

/**
 * Created with IntelliJ IDEA.
 * User: CD99910
 * Date: 07/03/13
 * Time: 11:23
 * To change this template use File | Settings | File Templates.
 */
public class ChildNodeElement1 implements IBaseNodeElement {
    private String name;
    private int ID = 1;

    public ChildNodeElement1(String name) {
        this.name = name;
    }

    public void setName(String name) {
        this.name = name;
        System.out.println("node1 name changed to " + name);
    }

    public void setID(int ID) {
        this.ID = ID;
        System.out.println("node 1 id changed to " + ID);
    }

    @Override
    public void accept(NodeElementVisitor nodeElementVisitor) {
        nodeElementVisitor.visit(this);
    }
}
