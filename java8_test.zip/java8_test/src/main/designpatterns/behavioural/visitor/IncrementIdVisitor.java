package main.designpatterns.behavioural.visitor;

/**
 * Created with IntelliJ IDEA.
 * User: CD99910
 * Date: 07/03/13
 * Time: 11:53
 * To change this template use File | Settings | File Templates.
 */
public class IncrementIdVisitor implements NodeElementVisitor{

    @Override
    public void visit(BaseNodeElement baseNodeElement) {
        baseNodeElement.setID(1);
    }

    @Override
    public void visit(ChildNodeElement1 childNodeElement1) {
        childNodeElement1.setID(2);
    }

    @Override
    public void visit(ChildNodeElement2 childNodeElement2) {
        childNodeElement2.setID(3);
    }

    @Override
    public void visit(ChildNodeElement3 childNodeElement3) {
         childNodeElement3.setID(4);
    }
}
