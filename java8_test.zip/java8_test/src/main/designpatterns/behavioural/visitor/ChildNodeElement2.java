package main.designpatterns.behavioural.visitor;

/**
 * Created with IntelliJ IDEA.
 * User: CD99910
 * Date: 07/03/13
 * Time: 11:24
 * To change this template use File | Settings | File Templates.
 */
public class ChildNodeElement2 implements IBaseNodeElement {
     private String name;
    private int ID = 2;

    public ChildNodeElement2(String name) {
        this.name = name;
    }

    public void setName(String name) {
        this.name = name;
        System.out.println("node 2 name changed to " + name);
    }

    public void setID(int ID) {
        this.ID = ID;
        System.out.println("node 2 id changed to " + ID);
    }

    @Override
    public void accept(NodeElementVisitor nodeElementVisitor) {
        nodeElementVisitor.visit(this);
    }
}
