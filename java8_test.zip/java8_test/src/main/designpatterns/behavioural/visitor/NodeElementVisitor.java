package main.designpatterns.behavioural.visitor;

/**
 * Created with IntelliJ IDEA.
 * User: CD99910
 * Date: 07/03/13
 * Time: 11:26
 * To change this template use File | Settings | File Templates.
 */
public interface NodeElementVisitor {
    void visit(BaseNodeElement baseNodeElement);
    void visit(ChildNodeElement1 childNodeElement1);
    void visit(ChildNodeElement2 childNodeElement2);
    void visit(ChildNodeElement3 childNodeElement3);
}
