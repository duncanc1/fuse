package main.designpatterns.behavioural.command;

import java.io.IOException;

/**
 * Created with IntelliJ IDEA.
 * User: CD99910
 * Date: 07/03/13
 * Time: 10:33
 * To change this template use File | Settings | File Templates.
 */
public class TestCommand {

    public static void main(String[]args)throws IOException{
        //aggregation - soft "has-a" association(empty diamond) i.e when conataining class destroyed - receiver not
        //composition - hard "owns-s" association(filled diamond) i.e strong life cycle association

        CrudReceiver receiver = new CrudReceiver();
        Command deleteCommand = new DeleteCommandImpl(receiver);
        Command saveCommand = new SaveCommandImpl(receiver);

        int i = 0;
        //invoker
        CrudInvoker invoker = new CrudInvoker();
        if(i == 0)
        {
            invoker.storeAndExecute(deleteCommand);
        }
        else
        {
            invoker.storeAndExecute(saveCommand);
        }


    }
}
