package main.designpatterns.behavioural.command;

/**
 * Created with IntelliJ IDEA.
 * User: CD99910
 * Date: 07/03/13
 * Time: 10:32
 * To change this template use File | Settings | File Templates.
 */
public class SaveCommandImpl implements Command{
    private CrudReceiver receiver;

    public SaveCommandImpl(CrudReceiver receiver) {
        this.receiver = receiver;
    }

    @Override
    public void execute() {
        this.receiver.doSave();
    }
}
