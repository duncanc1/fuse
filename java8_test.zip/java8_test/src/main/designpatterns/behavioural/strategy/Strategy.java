package main.designpatterns.behavioural.strategy;

/**
 * Created with IntelliJ IDEA.
 * User: CD99910
 * Date: 07/03/13
 * Time: 13:15
 * To change this template use File | Settings | File Templates.
 */
public interface Strategy {
    int executeAlgorithm(int a, int b);
}
