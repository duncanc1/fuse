package main.designpatterns.behavioural.observer;

import java.util.Observable;
import java.util.Observer;

/**
 * Created with IntelliJ IDEA.
 * User: CD99910
 * Date: 07/03/13
 * Time: 12:22
 * To change this template use File | Settings | File Templates.
 */
public class ResponseHandler implements Observer {
    private String resp;

    @Override
    public void update(Observable o, Object arg) {
        if(arg instanceof String)
        {
            resp = (String)arg;
            System.out.println("received response: " + resp);
        }
    }
}
