package main.designpatterns.behavioural.observer;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Observable;

/**
 * Created with IntelliJ IDEA.
 * User: CD99910
 * Date: 07/03/13
 * Time: 12:27
 * To change this template use File | Settings | File Templates.
 */
public class EventSource extends Observable implements Runnable{

    @Override
    public void run() {
        try {
            final InputStreamReader isr = new InputStreamReader(System.in);
            final BufferedReader br = new BufferedReader(isr);
            while (true) {
                String response = br.readLine();
                setChanged();
                notifyObservers(response);
            }

        }catch (IOException e) {
            e.printStackTrace();
        }

    }

}
