package main.designpatterns.singleton;

/**
 * Created with IntelliJ IDEA.
 * User: CD99910
 * Date: 07/03/13
 * Time: 13:47
 * To change this template use File | Settings | File Templates.
 */
public class BillPughSingleton {

    private BillPughSingleton() { }

    /**
     * SingletonHolder is loaded on the first execution of Singleton.getInstance()
     * or the first access to SingletonHolder.INSTANCE, not before.
     */
    private static class SingletonHolder {
        public static final BillPughSingleton INSTANCE = new BillPughSingleton();
    }

    public static BillPughSingleton getInstance() {
        return SingletonHolder.INSTANCE;
    }

}
