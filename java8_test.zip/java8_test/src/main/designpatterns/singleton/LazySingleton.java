package main.designpatterns.singleton;

/**
 * Created with IntelliJ IDEA.
 * User: CD99910
 * Date: 07/03/13
 * Time: 14:00
 * To change this template use File | Settings | File Templates.
 */
public class LazySingleton {

    private static LazySingleton instance = null;

    private LazySingleton() {       }

    public static LazySingleton getInstance() {
        if (instance == null) {
            synchronized (LazySingleton .class){
                if (instance == null) {
                    instance = new LazySingleton ();
                }
            }
        }
        return instance;
    }

}
