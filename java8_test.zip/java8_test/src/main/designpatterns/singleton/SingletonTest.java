package main.designpatterns.singleton;

import java.lang.reflect.Constructor;

/**
 * Created with IntelliJ IDEA.
 * User: CD99910
 * Date: 07/03/13
 * Time: 13:49
 * To change this template use File | Settings | File Templates.
 */
public class SingletonTest {

    public static BillPughSingleton createAnotherOne()
    {
        BillPughSingleton singleton = null ;
        try{
            Constructor[]  cs = BillPughSingleton.class.getDeclaredConstructors();
            for ( Constructor c : cs ){
                //This is where people can destroy the pattern.
                c.setAccessible( true );
                singleton = (BillPughSingleton)c.newInstance();
                break;
            }
        }catch (Exception e){
            e.printStackTrace();
        }
        return singleton;
    }


    public static EagerSingleton createAnotherEagerOne()
    {
        EagerSingleton singleton = null ;
        try{
            Constructor[]  cs = EagerSingleton.class.getDeclaredConstructors();
            for ( Constructor c : cs ){
                //This is where people can destroy the pattern.
                c.setAccessible( true );
                singleton = (EagerSingleton)c.newInstance();
                break;
            }
        }catch (Exception e){
            e.printStackTrace();
        }
        return singleton;
    }

    public static LazySingleton createAnotherLazyOne()
    {
        LazySingleton singleton = null ;
        try{
            Constructor[]  cs = LazySingleton.class.getDeclaredConstructors();
            for ( Constructor c : cs ){
                //This is where people can destroy the pattern.
                c.setAccessible( true );
                singleton = (LazySingleton)c.newInstance();
                break;
            }
        }catch (Exception e){
            e.printStackTrace();
        }
        return singleton;
    }

    public static void main(String[] args) {
        //System.out.println(BillPughSingleton.getInstance().hashCode() );
        //System.out.println( createAnotherOne().hashCode() );
        //System.out.println(BillPughSingleton.getInstance().hashCode() );

        //EAGER SINGLETON used when object creation is not expensive
        //System.out.println(main.designpatterns.singleton.EagerSingleton.getInstance().hashCode() );
        //System.out.println( createAnotherOne().hashCode() );
        //System.out.println(main.designpatterns.singleton.EagerSingleton.getInstance().hashCode() );


        //LAZY - used when object creation is expensive
        System.out.println(LazySingleton.getInstance().hashCode() );
        System.out.println( createAnotherOne().hashCode() );
        System.out.println(LazySingleton.getInstance().hashCode() );


    }

}
