package main;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.*;

public class VowelRecognition {

  public static void main(String[] args) throws Exception{

    //Scanner s = new Scanner(System.in);

    BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
    String test = br.readLine();
    int t = br.read();                // Reading input from STDIN
    //System.out.println("Hi, " + name + ".");    // Writing output to STDOUT

    //int t = s.nextInt();


      for (int i = 0; i < t; i++) {
        String str = br.readLine();
        System.out.println(getVowelCount(str));
      }


  }

  public static int getVowelCount(String str) {
    ArrayList<String> perms = new ArrayList<>();
    for (int i = 0; i < str.length(); i++) {
      perms.addAll(getPerms(str.substring(i)));
    }

    int vowelCount = 0;
    for (String permStr: perms) {
      vowelCount = vowelCount + containsVowel(permStr);
    }
    return vowelCount;
  }

  private static int containsVowel(String str) {
    int vowelCount = 0;
    for (int i = 0; i < str.length(); i++) {
      //one of these
      /*if(str.toLowerCase().charAt(i) == 'a' || str.charAt(i) =='e' || str.charAt(i) =='i' || str.charAt(i) =='o' || str.charAt(i) =='u') {
        vowelCount++;
      }*/

      switch (str.charAt(i)) {
        case 'a':
        case 'e':
        case 'i':
        case 'o':
        case 'u':
          vowelCount++;
          default:
      }

    }

    return vowelCount;
  }

  /**
   * 1. find all possible substrings and store
   * @return
   */
  public static HashSet<String> getPerms(String str) {

    if(str == null) {
      return null;
    }
    HashSet<String> permutationSet = new HashSet<>();
    //ArrayList<String> permutations = new ArrayList<>();
    if(str.length() < 2) {
      permutationSet.add(str);
      return permutationSet;
    }

    permutationSet.add(str);
    String remainder = str.substring(0, str.length() - 1);
    HashSet<String> words = getPerms(remainder);
    permutationSet.addAll(words);
    return permutationSet;

  }

}
