package main;

import java.util.Scanner;

public class PrimeNumber2 {

  public static void main(String[] args) {
    //Scanner s = new Scanner(System.in);
    int a = 10;
    int b = 50;
    // Write your code here

    StringBuilder builder = new StringBuilder();
    for(int i=a; i<=b; i++) {
      if(primeNumbers(i, 2)  && primeNumbers(sumDigits(i), 2)) {
        builder.append(i + " ");
      }
    }

    System.out.println(builder.toString());
  }


  private static Boolean primeNumbers(int n, int i) {
    // Base cases
    if (n <= 2)
      return n == 2 ? true : false;
    if (n % i == 0)
      return false;
    if (i * i > n) {
      return true;
    } else {
      return primeNumbers(n, i + 1);
    }


    // Check for next divisor

  }


  static int sumDigits(int no)
  {
    return no == 0 ? 0 : no%10 +
      sumDigits(no/10) ;
  }
}
