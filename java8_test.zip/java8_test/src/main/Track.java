package main;

/**
 * Created by duncanc1 on 08/09/2016.
 */
public class Track {

  private String name;
  private int length;

  public Track(String name, int trackLength) {
    this.name = name;
    this.length = trackLength;
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public int getLength() {
    return length;
  }

  public void setLength(int length) {
    this.length = length;
  }

  @Override
  public String toString() {
    return "main.Track{" +
      "name='" + name + '\'' +
      ", length=" + length +
      '}';
  }
}
