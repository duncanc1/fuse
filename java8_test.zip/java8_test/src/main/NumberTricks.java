package main;

public class NumberTricks {
  public static void main(String[] args) {
    int n = 234;
    System.out.println(sumDigits(n));
    n = 100000;
    executeEvery(n);

    n = 30;
    int m = 40;
    quickSwapNumbers(n, m);

    System.out.println((int)numberOfDigits(1000333));
  }

  static int sumDigits(int no)
  {
    return no == 0 ? 0 : no%10 +
      sumDigits(no/10) ;
  }

  static void executeEvery(int n) {
    for (int i = 0; i < 1000000 ; i++) {
      if(i%n == 0) {
        System.out.println("Code executed at :" + i);
      }
    }
  }

  static void quickSwapNumbers(int a, int b) {
    a ^= b;
    b ^= a;
    a ^= b;
    System.out.println("a=" + a);
    System.out.println("b=" + b);

  }

  static double numberOfDigits(int n) {
    return Math.floor(Math.log10(n)) + 1;
  }
}
