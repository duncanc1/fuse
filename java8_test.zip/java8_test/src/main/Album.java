package main;

import java.util.List;
import java.util.stream.Stream;

/**
 * Created by duncanc1 on 08/09/2016.
 */
public class Album {

  private String name;
  private List<Track> tracks;
  private List<Artist> musicians;

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public Stream<Track> getTracks() {
    return tracks.stream();
  }

  public void setTracks(List<Track> tracks) {
    this.tracks = tracks;
  }

  public Stream<Artist> getMusicians() {
    return musicians.stream();
  }

  public void setMusicians(List<Artist> musicians) {
    this.musicians = musicians;
  }
}
