import java.util.ArrayList;
import java.util.List;


/**
 * Created by duncanc1 on 11/12/2016.
 */
public class CovariantAndPassByValueReferenceTest {

  public static class Animal {

    void type() {
      System.out.println("Animal");
    }
  }

  public static class Horse extends Animal{

    void type() {
      System.out.println("Horse");
    }
  }

  public static class Cat extends Animal{

    void type() {
      System.out.println("Cat");
    }
  }


  public static void main(String[] args) {

    List<? extends Animal> list = new ArrayList<>();
    //list.add(new Horse());
    //list.add(new Animal());

    //CAUSES COMPILE ERROR - COVARIANCE lets you read from the list but nor write to it.

    //Animal cat = list.get(0);

    List<? super Animal> list2 = new ArrayList<>();
    list2.add(new Horse());
    list2.add(new Animal());

    //CONTRAVARIANCE - lets you write to the list but not read from.

    //Animal cat = list2.get(0);

    List<Animal> list3 = new ArrayList<>();
    list3.add(new Horse());
    list3.add(new Cat());

    Animal an = list3.get(0);

    an.type();





    int i = 1;
    Integer integer = Integer.valueOf(2);
    String str = "test";

    System.out.println("int before: " + i);
    changeTest(i);
    System.out.println("int after: " + i);

    //can change but only if reassigning to a new
    System.out.println("int before: " + i);
    i = changeTest(i);
    System.out.println("int after: " + i);


    System.out.println("Integer before: " + integer);
    changeObject(integer);
    System.out.println("Integer after: " + integer);

    System.out.println("Integer before: " + integer);
    integer = changeObjectReturnDifferent(integer);
    System.out.println("Integer after: " + integer);


    CovariantAndPassByValueReferenceTest co = new CovariantAndPassByValueReferenceTest();
    TestObject test = co.new TestObject();

    test.name = "New Name";
    System.out.println("Name before: " + test.name);
    changeObj(test);
    System.out.println("Name after: " + test.name);

    //String immutable so cannot change
    System.out.println("String before change: " + str);
    changeStringTest(str);
    System.out.println("string after change: "  + str);

    System.out.println("String before change: " + str);
    str = changeStringTestReassign(str);
    System.out.println("string after change: "  + str);
  }

  static void changeStringTest(String str) {
    str = "new test";
  }

  static String changeStringTestReassign(String str) {
    return "changed string";
  }

  static int changeTest(int i) {
    i++;
    return i;
  }


  static void changeObject(Integer i) {
    i = Integer.valueOf(8);
  }

  static Integer changeObjectReturnDifferent(Integer i) {
    return Integer.valueOf(8);
  }

  static void changeObj(TestObject obj) {
    obj.name = "Changed";
  }

  public class TestObject {
    private String name;

    public String getName() {
      return name;
    }

    public void setName(String name) {
      this.name = name;
    }
  }
}
