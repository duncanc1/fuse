package lambda;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 * Created by duncanc1 on 01/11/2016.
 */
public class TestTest {

  public static void main(String[] args) {


    int a = 9, b=2;
    float f;
    f = a / b;
    System.out.println(f);
    f = f / 2;
    System.out.println(f);
    f = a + b / f;
    System.out.println(f);

    List<String> strs = new ArrayList<>();
    strs.add("1");
    strs.add("2");

    strs.forEach((it) -> System.out.println("str:" + it));

    strs.parallelStream();

  }
}
