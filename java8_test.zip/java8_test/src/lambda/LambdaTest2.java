package lambda;

import java.io.IOException;
import java.util.Comparator;

/**
 * Created by duncanc1 on 26/10/2016.
 */
public class LambdaTest2 {

  public static void main(String[]args) throws IOException{
    Runnable r2 = () -> System.out.println("Howdy");
    r2.run();

    Comparator<String> c = (String lhs, String rhs) -> lhs.compareTo(rhs);
    int result = c.compare("Hello", "World");
    System.out.println(result);

    //type inference - no string type needed
    Comparator<String> c1 = ( lhs,  rhs) ->
    {
      return lhs.compareTo(rhs);
    };
    int result1 = c1.compare("Hello", "World");
    System.out.println(result1);
  }
}
