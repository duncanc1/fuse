/**
 * Created by duncanc1 on 09/12/2016.
 */
public class PrimitiveCastTest {

  public static void main(String[] args) {
    byte b = 1;
    short s = 1;
    char c = 'a';
    int i = 1;
    float f = 2f;
    long l = 12;
    double d = 2.00d;

    short s1 = b;//legal up implicit
    byte b1 = (byte)s;//down/narrowing so need explicit cast
    char c1 = (char)s;//explicit cast needed
    int i1 = s;
    i1 = b;
    i1 = c;

    double d1 = i1;


    int a = 6;
    int b2 = a;

    b2= 45;
    System.out.println(a);



  }
}
